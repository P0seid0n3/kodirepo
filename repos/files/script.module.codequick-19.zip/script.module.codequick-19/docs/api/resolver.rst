Resolver
========
This module is used for the creation of “Route callbacks”.

.. autoclass:: codequick.resolver.Resolver
    :members:
    :exclude-members: create_loopback
