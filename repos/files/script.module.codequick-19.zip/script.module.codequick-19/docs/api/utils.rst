Utils
=====
A collection of useful functions.

.. automodule:: codequick.utils
   :members:
