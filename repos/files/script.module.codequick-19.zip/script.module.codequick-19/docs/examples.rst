========
Examples
========
There are no better examples than actual add-on's that use the codequick framework.
So here is a list of add-ons that use this framework.

* https://github.com/willforde/plugin.video.watchmojo
* https://github.com/willforde/plugin.video.earthtouch
* https://github.com/willforde/plugin.video.metalvideo
* https://github.com/willforde/plugin.video.science.friday
